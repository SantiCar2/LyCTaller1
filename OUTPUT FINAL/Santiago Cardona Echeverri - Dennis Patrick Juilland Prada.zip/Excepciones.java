
public class Excepciones extends Exception {//Esta clase la utilizamos para manejar nuestras excepciones
	public Excepciones(String texto) {
		super(texto);
	}
}
